*****Technology*****
JAVA 1.8 or higher
TestNG 7.3
Selenium 3.141.59
Surefire Reports - in target folder after tests run
Maven
Chrome driver 88

*****file change needed*****
in base/TestBase.jave change the location of where you want to store config.properties file

*****to run it*****
cd into the test folder and from the terminal type
'mvn clean teat'